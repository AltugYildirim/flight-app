from crypt import methods
from os import abort
from flask import Flask, Blueprint, request, make_response 
from base64 import b64decode
from jwcrypto import jwt, jwk
import time

# from werkzeug.security import check_password_hash, generate_password_hash
from flights.db import get_db
import json
from jwcrypto import jwt

bp = Blueprint('flights_impl', __name__, url_prefix='/api/v1')
app = Flask(__name__)

##########################################################
##########################################################
##########################################################
@bp.route('/login', methods=['POST'])
def post_login():
  app.logger.info(">>>>POST /login")
  result = {"token": "value"}
  try:
    authHeaderValue = request.headers.get('authorization').split(" ")[1]    
    app.logger.info(f"Base64 value {b64decode(authHeaderValue).decode()}")
    (user,passwd) = b64decode(authHeaderValue).decode().split(':')
    app.logger.info(f"User: {user}")
    app.logger.info(f"Passwd: {passwd}")
    key = jwk.JWK().from_password("your-256-bit-secret")
    token = jwt.JWT(
      header = {"alg": "HS256","typ": "JWT"},
      claims = {"sub": "1234567890", "name": f"{user} {passwd} noname", "iat": int(time.time())}
    )
    token.make_signed_token(key)
    result["token"] = token.serialize()
    resp = make_response(json.dumps(result),201)
    resp.headers["Content-Type"] = "application/json"
  except Exception as err:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},400)
    resp.headers["Content-Type"]="application/json"
  
  return resp


##########################################################
##########################################################
##########################################################
@bp.route('/flights', methods=['GET'])
def get_flights():
  app.logger.info(">>>>GET /flights")
  db = get_db()

  app.logger.info('Query params: %s',request.args)

  try:
    authHeader = request.headers.get('authorization')
    authToken = authHeader.split(" ")[1]
    payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
    assert "noname" in payload['name'].lower()
  except Exception as err:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    cur = db.cursor()
    if 'destination' in request.args:
      dest = request.args['destination']
      rows = cur.execute("SELECT * FROM flights WHERE destination = ?", (dest,)).fetchall()
    else:
      rows = cur.execute("SELECT * FROM flights").fetchall()
    cur.close()
  except Exception as err:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    resp.headers["Content-Type"]="application/json"
    return resp
  finally:
    cur.close()
  
  resp = make_response(json.dumps(rows))
  resp.headers["Content-Type"] = "application/json"
  resp.headers["Result-Count"] = len(rows)

  return resp


##########################################################
##########################################################
##########################################################
@bp.route('/flights/<int:id>', methods=['GET'])
def get_flight_by_id(id):
  app.logger.info(">>>>GET /flights/\{flight_id\}")
  db = get_db()

  app.logger.info("ID: %s",id)

  try:
    authHeader = request.headers.get('authorization')
    authToken = authHeader.split(" ")[1]
    payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
    assert "noname" in payload['name'].lower()
  except Exception as err:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    cur = db.cursor()
    row = cur.execute("SELECT * FROM flights WHERE id = ?", (id,)).fetchall()
    cur.close()
    app.logger.info("Row data: %s",row)
    if len(row) == 0:
      return "No record found", 404
  except Exception as err:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    resp.headers["Content-Type"]="application/json"
    return resp
  finally:
    cur.close()

  resp = make_response(json.dumps(row[0]))
  resp.headers["Content-Type"] = "application/json"

  return resp

##########################################################
##########################################################
##########################################################
@bp.route('/flights', methods=["POST"])
def post_flights():
  app.logger.info(">>>>POST /flights")
  assert request.path == '/api/v1/flights'
  assert request.method == 'POST'
  reqBody = request.get_json()
  app.logger.info(json.dumps(reqBody))
  requiredFields = ['code','carrier','destination','origin','departure','price','plane','tseats','eseats']

  try:
    authHeader = request.headers.get('authorization')
    authToken = authHeader.split(" ")[1]
    payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
    assert "noname" in payload['name'].lower()
  except Exception as err:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    for f in requiredFields:
      assert f in reqBody and reqBody[f]
  except AssertionError:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},400)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    db = get_db()
    cur = db.cursor()
    insertStmt = "INSERT INTO flights ("+ ",".join(requiredFields) +") VALUES (?,?,?,?,?,?,?,?,?)"
    app.logger.info(insertStmt)
    insertVals = [reqBody[f] for f in requiredFields]
    result = cur.execute(insertStmt,insertVals)
    app.logger.info(result.lastrowid)
    db.commit()
    cur.close()
    resp = make_response({"message": "Success"}, 201)
    # resp = make_response({"message": "Success","flight_id": result.lastrowid}, 201)
    # resp = make_response({"message": "Success","bogus": result.lastrowid}, 201)
    resp.headers["Content-Type"]="application/json"
    return resp
  except Exception:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    resp.headers["Content-Type"]="application/json"
    return resp
  finally:
    cur.close()
